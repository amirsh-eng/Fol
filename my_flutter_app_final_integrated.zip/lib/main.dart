import 'package:flutter/material.dart';
import 'screens/students_screen.dart';
import 'screens/attendance_screen.dart';
import 'screens/reports_screen.dart';
import 'screens/settings_screen.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: HomeScreen(),
    );
  }
}

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('نظام إدارة المدرسة')),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration: BoxDecoration(color: Colors.blue),
              child: Text('القائمة الرئيسية', style: TextStyle(color: Colors.white, fontSize: 24)),
            ),
            ListTile(
              leading: Icon(Icons.person),
              title: Text('إدارة الطلاب'),
              onTap: () {
                Navigator.push(context, MaterialPageRoute(builder: (context) => StudentsScreen()));
              },
            ),
            ListTile(
              leading: Icon(Icons.check_circle),
              title: Text('تسجيل الحضور'),
              onTap: () {
                Navigator.push(context, MaterialPageRoute(builder: (context) => AttendanceScreen()));
              },
            ),
            ListTile(
              leading: Icon(Icons.bar_chart),
              title: Text('التقارير والإحصائيات'),
              onTap: () {
                Navigator.push(context, MaterialPageRoute(builder: (context) => ReportsScreen()));
              },
            ),
            ListTile(
              leading: Icon(Icons.settings),
              title: Text('الإعدادات'),
              onTap: () {
                Navigator.push(context, MaterialPageRoute(builder: (context) => SettingsScreen()));
              },
            ),
          ],
        ),
      ),
      body: Center(child: Text('مرحبًا بك في نظام إدارة المدرسة')),
    );
  }
}
