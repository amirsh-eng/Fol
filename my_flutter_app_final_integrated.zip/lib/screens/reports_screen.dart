import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import '../services/pdf_service.dart';
import '../services/attendance_service.dart';

class ReportsScreen extends StatefulWidget {
  @override
  _ReportsScreenState createState() => _ReportsScreenState();
}

class _ReportsScreenState extends State<ReportsScreen> {
  final AttendanceDatabaseHelper dbHelper = AttendanceDatabaseHelper.instance;
  int presentCount = 0;
  int absentCount = 0;

  @override
  void initState() {
    super.initState();
    _calculateAttendanceStats();
  }

  Future<void> _calculateAttendanceStats() async {
    final records = await dbHelper.getAttendanceRecords();
    setState(() {
      presentCount = records.where((r) => r['status'] == 'حاضر').length;
      absentCount = records.where((r) => r['status'] == 'غائب').length;
    });
  }

  Future<void> _exportPDF() async {
    await PdfService.generateStyledStudentReport([
      {'id': '1', 'name': 'أحمد', 'grade': '90'},
      {'id': '2', 'name': 'محمد', 'grade': '85'},
    ]);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تم تصدير التقرير إلى PDF!')));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('التقارير والإحصائيات')),
      body: Column(
        children: [
          Expanded(
            child: PieChart(
              PieChartData(
                sections: [
                  PieChartSectionData(value: presentCount.toDouble(), title: 'حاضر', color: Colors.green),
                  PieChartSectionData(value: absentCount.toDouble(), title: 'غائب', color: Colors.red),
                ],
              ),
            ),
          ),
          ElevatedButton(
            onPressed: _exportPDF,
            child: Text('تصدير تقرير الحضور PDF'),
          ),
        ],
      ),
    );
  }
}
