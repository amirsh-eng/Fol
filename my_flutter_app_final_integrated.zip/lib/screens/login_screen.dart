import 'package:flutter/material.dart';
import '../database/database_helper.dart';
import 'dashboard_screen.dart';

class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final DatabaseHelper dbHelper = DatabaseHelper.instance;

  Future<void> _login() async {
    String email = emailController.text;
    String password = passwordController.text;

    bool success = await dbHelper.loginUser(email, password);
    if (success) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => DashboardScreen()),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('فشل تسجيل الدخول، تحقق من البريد وكلمة المرور!')),
      );
    }
  }

  Future<void> _register() async {
    String email = emailController.text;
    String password = passwordController.text;

    if (email.isNotEmpty && password.isNotEmpty) {
      await dbHelper.registerUser(email, password);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('تم التسجيل بنجاح! يمكنك الآن تسجيل الدخول.')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('تسجيل الدخول')),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextField(
              controller: emailController,
              decoration: InputDecoration(labelText: 'البريد الإلكتروني'),
            ),
            TextField(
              controller: passwordController,
              decoration: InputDecoration(labelText: 'كلمة المرور'),
              obscureText: true,
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _login,
              child: Text('تسجيل الدخول'),
            ),
            TextButton(
              onPressed: _register,
              child: Text('إنشاء حساب جديد'),
            ),
          ],
        ),
      ),
    );
  }
}
