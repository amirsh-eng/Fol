import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import '../services/attendance_service.dart';

class AttendanceReportsScreen extends StatefulWidget {
  @override
  _AttendanceReportsScreenState createState() => _AttendanceReportsScreenState();
}

class _AttendanceReportsScreenState extends State<AttendanceReportsScreen> {
  final AttendanceDatabaseHelper dbHelper = AttendanceDatabaseHelper.instance;
  int presentCount = 0;
  int absentCount = 0;

  @override
  void initState() {
    super.initState();
    _calculateAttendanceStats();
  }

  Future<void> _calculateAttendanceStats() async {
    final records = await dbHelper.getAttendanceRecords();
    setState(() {
      presentCount = records.where((r) => r['status'] == 'حاضر').length;
      absentCount = records.where((r) => r['status'] == 'غائب').length;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('تقارير الحضور')),
      body: Column(
        children: [
          SizedBox(height: 20),
          Text('إحصائيات الحضور', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          Expanded(
            child: PieChart(
              PieChartData(
                sections: [
                  PieChartSectionData(value: presentCount.toDouble(), title: 'حاضر', color: Colors.green),
                  PieChartSectionData(value: absentCount.toDouble(), title: 'غائب', color: Colors.red),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
