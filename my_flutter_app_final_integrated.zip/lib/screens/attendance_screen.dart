import 'package:flutter/material.dart';
import '../services/qr_attendance_service.dart';
import '../services/gps_attendance_service.dart';

class AttendanceScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('تسجيل الحضور')),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          ElevatedButton(
            onPressed: () {
              Navigator.push(context, MaterialPageRoute(builder: (context) => QRGeneratorScreen(sessionId: '12345')));
            },
            child: Text('تسجيل الحضور عبر QR Code'),
          ),
          SizedBox(height: 10),
          ElevatedButton(
            onPressed: () {
              Navigator.push(context, MaterialPageRoute(builder: (context) => GPSAttendanceScreen()));
            },
            child: Text('تسجيل الحضور عبر GPS'),
          ),
        ],
      ),
    );
  }
}
