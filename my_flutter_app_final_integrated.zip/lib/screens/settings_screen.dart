import 'package:flutter/material.dart';

class SettingsScreen extends StatefulWidget {
  @override
  _SettingsScreenState createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool notificationsEnabled = true;
  bool firebaseSync = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('الإعدادات')),
      body: Column(
        children: [
          SwitchListTile(
            title: Text('تفعيل الإشعارات'),
            value: notificationsEnabled,
            onChanged: (bool value) {
              setState(() {
                notificationsEnabled = value;
              });
            },
          ),
          SwitchListTile(
            title: Text('مزامنة البيانات مع Firebase'),
            value: firebaseSync,
            onChanged: (bool value) {
              setState(() {
                firebaseSync = value;
              });
            },
          ),
        ],
      ),
    );
  }
}
