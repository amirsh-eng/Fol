import 'package:flutter/material.dart';
import '../services/students_service.dart';

class StudentsScreen extends StatefulWidget {
  @override
  _StudentsScreenState createState() => _StudentsScreenState();
}

class _StudentsScreenState extends State<StudentsScreen> {
  final StudentDatabaseHelper dbHelper = StudentDatabaseHelper.instance;
  List<Map<String, dynamic>> students = [];
  String searchQuery = "";

  TextEditingController nameController = TextEditingController();
  TextEditingController gradeController = TextEditingController();
  TextEditingController searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadStudents();
  }

  Future<void> _loadStudents() async {
    final data = await dbHelper.getStudents();
    setState(() {
      students = data;
    });
  }

  Future<void> _addStudent() async {
    String name = nameController.text;
    int grade = int.tryParse(gradeController.text) ?? 0;

    if (name.isNotEmpty && grade > 0) {
      await dbHelper.addStudent(name, grade);
      nameController.clear();
      gradeController.clear();
      _loadStudents();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('إدارة الطلاب')),
      body: Column(
        children: [
          Padding(
            padding: EdgeInsets.all(16.0),
            child: Column(
              children: [
                TextField(controller: nameController, decoration: InputDecoration(labelText: 'اسم الطالب')),
                TextField(controller: gradeController, decoration: InputDecoration(labelText: 'الدرجة'), keyboardType: TextInputType.number),
                SizedBox(height: 10),
                ElevatedButton(onPressed: _addStudent, child: Text('إضافة طالب')),
                TextField(
                  controller: searchController,
                  decoration: InputDecoration(labelText: 'بحث عن طالب'),
                  onChanged: (value) {
                    setState(() {
                      searchQuery = value;
                    });
                  },
                ),
              ],
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: students.length,
              itemBuilder: (context, index) {
                if (searchQuery.isNotEmpty &&
                    !students[index]['name'].toLowerCase().contains(searchQuery.toLowerCase())) {
                  return Container();
                }
                return ListTile(
                  title: Text(students[index]['name']),
                  subtitle: Text('الدرجة: ${students[index]['grade']}'),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
