import 'package:flutter/material.dart';

class GradesScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('إدارة الدرجات')),
      body: Center(
        child: Text('قائمة الدرجات ستظهر هنا', style: TextStyle(fontSize: 18)),
      ),
    );
  }
}
