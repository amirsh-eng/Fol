import 'package:geolocator/geolocator.dart';
import 'package:flutter/material.dart';
import '../services/attendance_service.dart';

class GPSAttendanceScreen extends StatefulWidget {
  @override
  _GPSAttendanceScreenState createState() => _GPSAttendanceScreenState();
}

class _GPSAttendanceScreenState extends State<GPSAttendanceScreen> {
  final AttendanceDatabaseHelper dbHelper = AttendanceDatabaseHelper.instance;
  Position? _currentPosition;

  Future<void> _getCurrentLocation() async {
    LocationPermission permission = await Geolocator.requestPermission();
    if (permission == LocationPermission.denied || permission == LocationPermission.deniedForever) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('يجب تفعيل GPS لتسجيل الحضور.')));
      return;
    }

    Position position = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
    setState(() {
      _currentPosition = position;
    });
  }

  Future<void> _recordAttendance() async {
    if (_currentPosition != null) {
      await dbHelper.addAttendance('طالب مجهول', 'حاضر', DateTime.now().toIso8601String());
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تم تسجيل الحضور بنجاح!')));
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذر تحديد موقعك، يرجى المحاولة مرة أخرى.')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('تسجيل الحضور عبر GPS')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(onPressed: _getCurrentLocation, child: Text('تحديد الموقع')),
            SizedBox(height: 10),
            ElevatedButton(onPressed: _recordAttendance, child: Text('تسجيل الحضور')),
          ],
        ),
      ),
    );
  }
}
