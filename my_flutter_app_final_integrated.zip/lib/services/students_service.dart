import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class StudentDatabaseHelper {
  static final StudentDatabaseHelper instance = StudentDatabaseHelper._init();
  static Database? _database;

  StudentDatabaseHelper._init();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB('students.db');
    return _database!;
  }

  Future<Database> _initDB(String filePath) async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, filePath);

    return await openDatabase(path, version: 1, onCreate: _createDB);
  }

  Future _createDB(Database db, int version) async {
    await db.execute('''
      CREATE TABLE students (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        grade INTEGER NOT NULL
      )
    ''');
  }

  Future<void> addStudent(String name, int grade) async {
    final db = await instance.database;
    await db.insert('students', {'name': name, 'grade': grade});
  }

  Future<List<Map<String, dynamic>>> getStudents() async {
    final db = await instance.database;
    return await db.query('students');
  }

  Future<void> updateStudent(int id, String name, int grade) async {
    final db = await instance.database;
    await db.update('students', {'name': name, 'grade': grade}, where: 'id = ?', whereArgs: [id]);
  }

  Future<void> deleteStudent(int id) async {
    final db = await instance.database;
    await db.delete('students', where: 'id = ?', whereArgs: [id]);
  }
}
