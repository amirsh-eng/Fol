import 'package:qr_flutter/qr_flutter.dart';
import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import '../services/attendance_service.dart';

class QRGeneratorScreen extends StatelessWidget {
  final String sessionId;

  QRGeneratorScreen({required this.sessionId});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('رمز QR للحضور')),
      body: Center(
        child: QrImage(
          data: sessionId,
          version: QrVersions.auto,
          size: 200.0,
        ),
      ),
    );
  }
}

class QRScannerScreen extends StatefulWidget {
  @override
  _QRScannerScreenState createState() => _QRScannerScreenState();
}

class _QRScannerScreenState extends State<QRScannerScreen> {
  final AttendanceDatabaseHelper dbHelper = AttendanceDatabaseHelper.instance;

  void _onQRViewCreated(String result) async {
    await dbHelper.addAttendance(result, 'حاضر', DateTime.now().toIso8601String());
    Navigator.pop(context);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تم تسجيل الحضور بنجاح!')));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('مسح رمز QR')),
      body: MobileScanner(
        onDetect: (barcode, args) {
          if (barcode.rawValue != null) {
            _onQRViewCreated(barcode.rawValue!);
          }
        },
      ),
    );
  }
}
