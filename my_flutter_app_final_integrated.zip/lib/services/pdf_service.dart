import 'dart:io';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:path_provider/path_provider.dart';

class PdfService {
  static Future<void> generateStyledStudentReport(List<Map<String, String>> students) async {
    final pdf = pw.Document();

    final arabicFont = pw.Font.ttf(await rootBundle.load("assets/fonts/Amiri-Regular.ttf"));

    pdf.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.a4,
        build: (pw.Context context) => pw.Column(
          children: [
            pw.Text("تقرير الطلاب", style: pw.TextStyle(font: arabicFont, fontSize: 24, color: PdfColors.blue)),
            pw.SizedBox(height: 20),
            pw.Table.fromTextArray(
              headers: ['الرقم', 'الاسم', 'الدرجة'],
              headerStyle: pw.TextStyle(font: arabicFont, fontSize: 14, color: PdfColors.white),
              headerDecoration: pw.BoxDecoration(color: PdfColors.blueGrey),
              cellStyle: pw.TextStyle(font: arabicFont, fontSize: 12, color: PdfColors.black),
              data: students.map((student) => [student['id'], student['name'], student['grade']]).toList(),
            ),
            pw.SizedBox(height: 20),
            pw.Text("تم إنشاء التقرير بتاريخ: ${DateTime.now().toLocal()}",
                style: pw.TextStyle(font: arabicFont, fontSize: 10, color: PdfColors.grey)),
          ],
        ),
      ),
    );

    final output = await getExternalStorageDirectory();
    final file = File("${output!.path}/styled_student_report.pdf");

    await file.writeAsBytes(await pdf.save());
  }
}
